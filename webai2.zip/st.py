import streamlit as st
import numpy as np
import pandas as pd
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer
import requests
from bs4 import BeautifulSoup
import re
import string

def process_url(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    text = ' '.join([p.text for p in soup.find_all('p')])

    text = text.lower()
    tokenized_words = word_tokenize(text)
    tokenized_words = [re.sub(f'[{string.punctuation}]+', '', i) for i in tokenized_words if i not in list(string.punctuation)]
    tokenized_words = [i for i in tokenized_words if i not in stopwords.words('english')]
    wordnetlemmatizer= WordNetLemmatizer()
    tokenized_words = [wordnetlemmatizer.lemmatize(i) for i in tokenized_words]
    processed_text = ' '.join(tokenized_words)

    return processed_text


def main():

    st.markdown("<h1 style='text-align: center;'>WebAI</h1>",
                unsafe_allow_html=True)

    st.subheader("Menu")
    if st.button("About"):
        st.write(
        "We make smart websites! We are a unique company, which aims to categorize websites and make them have artificial intelligence. WebAI is a company, which aims to make a unique and smart to categorization for websites. We have our own way to categorize websites and we're mastering these Machine Learning methods to advance further in this industry. Since our founding in 2022, we've been trying to achieve a success rate in web categorization and customer satisfaction. We also support intrapreneurship and project organizations as the team WebAI."
        )

    if st.button("GitHub"):
        st.write(
        "[GitHub](https://github.com/CankayaUniversity/ceng-407-408-2022-2023-Categorizing-Website-with-Data-Science)"
        )

    st.subheader("Search")
    search_query = st.text_input("Search Category")

    if st.button("Search"):
        # Load the trained model, TfidfVectorizer and LabelEncoder
        with open('model.pkl', 'rb') as file:
            model = pickle.load(file)
        with open('tf_idf_vectorizer.pkl', 'rb') as file:
            tf_idf_vectorizer = pickle.load(file)
        with open('category_mapping.pkl', 'rb') as file:
            category_mapping = pickle.load(file)

        # Process the URL
        processed_text = process_url(search_query)

        # Vectorize the processed text
        vectorized_text = tf_idf_vectorizer.transform([processed_text])

        # Predict the category
        category_id = model.predict(vectorized_text)[0]

        # Map the category_id back to the original category
        category = category_mapping[category_id]

        st.write("The predicted category of this website is: ", category)


if __name__ == "__main__":
    main()
