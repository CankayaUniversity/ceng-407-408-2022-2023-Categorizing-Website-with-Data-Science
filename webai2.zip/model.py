import numpy as np  # linear algebra
import pandas as pd  # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import seaborn as sb
import nltk
import string
import re
import sklearn.metrics as sm
import imblearn

##### read the dataset
website_df = pd.read_csv('website_classification.csv')
website_df

website_url_df = website_df[['website_url', 'Category']]

#### temporary purposes (deleting the unnamed: 0 & website_url)

website_df.drop(['Unnamed: 0', 'website_url'], axis=1, inplace=True)

#### let's study the count of each category

plt.figure(figsize=(12, 10))
plt.title('Category vs Counts')
website_category_df = pd.DataFrame(website_df.groupby('Category').size(),
                                   columns=['Count'])
plt.barh(width=website_category_df['Count'], y=website_category_df.index)
plt.show()
"""##### Almost all category are in same count except for forums and adults

##                                                      Data Cleaning & Engineering

#### converts the letters of word to lower case
"""

website_df['cleaned_website_text'] = website_df['cleaned_website_text'].apply(
  lambda x: x.lower())

import nltk

nltk.download('punkt')
"""##### splits the sentence to the list of words"""

from nltk.tokenize import word_tokenize

website_df['tokenized_words'] = website_df['cleaned_website_text'].apply(
  lambda x: word_tokenize(x))
"""#### removing special characters (if anything is there still)"""

website_df['tokenized_words'] = website_df['tokenized_words'].apply(lambda x: [
  re.sub(f'[{string.punctuation}]+', '', i) for i in x
  if i not in list(string.punctuation)
])
website_df

import nltk

nltk.download('stopwords')
"""#### Removing stopwords"""

from nltk.corpus import stopwords

website_df['tokenized_words'] = website_df['tokenized_words'].apply(
  lambda x: [i for i in x if i not in stopwords.words('english')])
website_df

nltk.download('wordnet')
"""#### Lemmatizing the words"""

from nltk.stem.wordnet import WordNetLemmatizer

wordnetlemmatizer = WordNetLemmatizer()
website_df['tokenized_words'] = website_df['tokenized_words'].apply(
  lambda x: [wordnetlemmatizer.lemmatize(i) for i in x])
website_df

#### join the tokenized words
website_df['tokenized_words'] = website_df['tokenized_words'].apply(
  lambda x: ' '.join(x))

# dropping the unnecessary columns
website_df.drop(['cleaned_website_text'], axis=1, inplace=True)

### changing the order of columns and renaming them

website_df = website_df[['tokenized_words', 'Category']]
website_df.columns = ['Website Cleaned Text', 'Category']

website_df

#### converts the category to labels using label encoding
from sklearn.preprocessing import LabelEncoder

le = LabelEncoder()
website_df['Category'] = le.fit_transform(website_df['Category'])

website_df

from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
  website_df['Website Cleaned Text'],
  website_df['Category'],
  test_size=0.3,
  random_state=0)

#### converting the text to frequency (using TF-IDF)
from sklearn.feature_extraction.text import TfidfVectorizer

tf_idf_vectorizer = TfidfVectorizer(lowercase=False)
X_train = tf_idf_vectorizer.fit_transform(X_train)
X_train = pd.DataFrame(X_train.toarray(),
                       columns=tf_idf_vectorizer.get_feature_names_out())

#### using the SMOTE/oversampler
from imblearn.over_sampling import SMOTE, RandomOverSampler

sampling_strategy = {
  14: 81,
  4: 77,
  3: 76,
  13: 75,
  8: 75,
  7: 72,
  15: 70,
  1: 69,
  2: 69,
  12: 65,
  9: 62,
  10: 59,
  5: 58,
  11: 54,
  0: 60,
  6: 60
}
oversample = RandomOverSampler(sampling_strategy=sampling_strategy)
X_train, y_train = oversample.fit_resample(X_train, y_train)

#### applying the algorithm
from sklearn.naive_bayes import MultinomialNB

model_clf = MultinomialNB()
model_clf.fit(X_train, y_train)

X_test = tf_idf_vectorizer.transform(X_test)
X_test = pd.DataFrame(X_test.toarray(),
                      columns=tf_idf_vectorizer.get_feature_names_out())
y_pred = model_clf.predict(X_test)
print(
  f'The accuracy of train model is {sm.accuracy_score(y_train, model_clf.predict(X_train))}'
)
print(f'The accuracy of test model is {sm.accuracy_score(y_test, y_pred)}')

results_df = pd.DataFrame({'Gerçek': y_test, 'Tahmin Edilen': y_pred})
results_df['Gerçek Kategori'] = le.inverse_transform(results_df['Gerçek'])
results_df['Tahmin Edilen Kategori'] = le.inverse_transform(results_df['Tahmin Edilen'])
print(results_df)