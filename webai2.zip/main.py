import streamlit as st
import numpy as np
import pandas as pd
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer
import requests
from bs4 import BeautifulSoup
import re
import string
import webbrowser


def process_url(url):
  try:
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    text = ' '.join([p.text for p in soup.find_all('p')])

    text = text.lower()
    tokenized_words = word_tokenize(text)
    tokenized_words = [
      re.sub(f'[{string.punctuation}]+', '', i) for i in tokenized_words
      if i not in list(string.punctuation)
    ]
    tokenized_words = [
      i for i in tokenized_words if i not in stopwords.words('english')
    ]
    wordnetlemmatizer = WordNetLemmatizer()
    tokenized_words = [wordnetlemmatizer.lemmatize(i) for i in tokenized_words]
    processed_text = ' '.join(tokenized_words)

    return processed_text
  except requests.exceptions.RequestException:
    st.write(
      "<div style='background-color: red; padding: 10px; border-radius: 5px;'>'Error occurred while accessing the URL. Please make sure the URL is correct and accessible.</div>",
      unsafe_allow_html=True)
    return None


def main():
  st.set_page_config(page_title='WebAI - Teknoloji Sitesi',
                     page_icon='logo.png')

  st.markdown("""
        <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url("animated.gif") no-repeat center center fixed;
            background-size: cover;
        }

        .container {
            max-width: 960px;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
        }

        h1 {
            color: #1282a2;
            font-size: 36px;
            font-weight: bold;
            margin-top: 20px;
        }

        .panel {
            background-color: #1282a2;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 40px;
        }

        .panel ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: center;
            gap: 20px;
        }

        .panel li {
            display: inline-block;
        }

        .panel a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .panel a:hover {
            background-color: #0d6472;
        }

        .search-container {
            text-align: center;
            margin-top: 50px;
        }

        .search-input {
            width: 400px;
            padding: 10px;
            font-size: 16px;
        }

        .search-button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #2b7a78;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .logo {
            margin-bottom: 20px;
            max-width: 200px;
            height: auto;
        }

        .about-content {
            text-align: left;
            margin-top: 40px;
        }

        .about-content h2 {
            color: #000000;  /* Siyah renk */
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .about-content p {
            font-size: 16px;
            line-height: 1.5;
        }

        .about-content img {
            max-width: 100%;
            height: auto;
            margin-top: 20px;
        }
        .hello-message {
                font-size: 24px;
                margin-top: 20px;
            }
            </style>
            """,
              unsafe_allow_html=True)

  st.markdown("""
            <div class="container">
                <header>
                    <h2 style="color: #05385B;"> <strong> WEBAI </strong></h2>
                    <nav class="panel">
                       <ul>
                        <li><a href="https://streamlit-2.gozdeat.repl.co/#about" >About</a></li>
                        <li><a href="https://github.com/CankayaUniversity/ceng-407-408-2022-2023-Categorizing-Website-with-Data-Science/wiki#contents">Files</a></li>
                        <li><a href="predictions.html">Predictions</a></li>
                        <li><a href="https://github.com/CankayaUniversity/ceng-407-408-2022-2023-Categorizing-Website-with-Data-Science">Github</a></li>
                    </ul>
                    </nav>
                </header>
            
            </div>
            <script>
            function handleLinkClick(link) {
                const data = { event: 'linkClick', link: link };
                window.parent.postMessage(data, '*'); 
            }
            </script>
            """,
              unsafe_allow_html=True)

  st.subheader("Search")
  search_query = st.text_input("Search Category")

  if st.button("Search"):
    if not search_query:
      st.warning("Please enter a URL!")
    elif not search_query.startswith(("http://", "https://")):
      st.write(
        "<div style='background-color: red; padding: 10px; border-radius: 5px;'>Invalid URL. Please enter a valid URL starting with 'http://' or 'https://'.</div>",
        unsafe_allow_html=True)
    else:
      # Load the trained model, TfidfVectorizer, and LabelEncoder
      with open('model.pkl', 'rb') as file:
        model = pickle.load(file)
      with open('tf_idf_vectorizer.pkl', 'rb') as file:
        tf_idf_vectorizer = pickle.load(file)
      with open('category_mapping.pkl', 'rb') as file:
        category_mapping = pickle.load(file)

      # Process the URL
      processed_text = process_url(search_query)

      # Vectorize the processed text
      vectorized_text = tf_idf_vectorizer.transform([processed_text])

      # Predict the category
      category_id = model.predict(vectorized_text)[0]

      # Map the category_id back to the original category
      category = category_mapping[category_id]

      st.write("The predicted category of this website is:", category)


if 'event' in st.session_state and st.session_state.event == 'onclick' and 'handleLinkClick' in st.session_state:
  if st.session_state.link == 'https://streamlit-2.gozdeat.repl.co/#about':
    st.subheader('About')

    st.write(
      "We make smart websites!  We are a unique company, which aims to categorize websites and make them have artificial intelligence. WebAI is a company, which aims to make a unique and smart to categorization for websites. We have our own way to categorize websites and we're mastering these Machine Learning methods to advance further in this industry. Since our founding in 2022, we've been trying to achieve a success rate in web categorization and customer satisfaction. We also support intrapreneurship and project organizations as the team WebAI."
    )

if __name__ == "__main__":
  main()
