# ceng-407-408-2022-2023-Categorizing-Website-with-Data-Science
Categorizing Website with Data Science
Welcome to the ceng-407-408-2022-2023-Categorizing-Website-with-Data-Science wiki!

## Advisor

* [Nurdan Saran](http://academic.cankaya.edu.tr/~buz/) & [Sevgi Koyuncu Tunç](sevgik@cankaya.edu.tr)


## Team Members

* [Beril Erken](https://github.com/berilerken)

* [Gözde Ataç](https://github.com/gozdeatac)

* [Yasmin Çınar](https://github.com/yasuolina)
